package com.smtaste.restaurant.controller;

public class UsuarioController {
}
