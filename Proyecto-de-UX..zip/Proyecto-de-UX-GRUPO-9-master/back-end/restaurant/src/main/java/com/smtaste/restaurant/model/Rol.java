package com.smtaste.restaurant.model;

public enum Rol {
    USER,
    ADMIN
}
